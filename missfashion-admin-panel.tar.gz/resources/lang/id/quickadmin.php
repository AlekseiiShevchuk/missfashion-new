<?php

return [
	'create' => 'Buat',
	'save' => 'Simpan',
	'edit' => 'Edit',
	'view' => 'Lihat',
	'update' => 'Update',
	'list' => 'Daftar',
	'no_entries_in_table' => 'Tidak ada data di tabel',
	'custom_controller_index' => 'Controller index yang sesuai kebutuhan Anda.',
	'logout' => 'Keluar',
	'add_new' => 'Tambahkan yang baru',
	'are_you_sure' => 'Anda yakin?',
	'back_to_list' => 'Kembali ke daftar',
	'dashboard' => 'Dashboard',
	'delete' => 'Hapus',
	'quickadmin_title' => 'missfashion admin panel',
		'user-management' => [		'title' => 'User Management',		'fields' => [		],	],
		'roles' => [		'title' => 'Roles',		'fields' => [			'title' => 'Title',		],	],
		'users' => [		'title' => 'Users',		'fields' => [			'name' => 'Name',			'email' => 'Email',			'password' => 'Password',			'role' => 'Role',			'remember-token' => 'Remember token',		],	],
		'donor' => [		'title' => 'Donor category links',		'fields' => [			'url' => 'Url to donor category',			'category' => 'Parsing inside Category',		],	],
		'categories' => [		'title' => 'Categories',		'fields' => [			'name' => 'Category name',			'parent' => 'Parent category',			'photo' => 'Photo for category',			'donors' => 'Donors links',		],	],
		'product-attributes' => [		'title' => 'Product attributes',		'fields' => [		],	],
		'images' => [		'title' => 'Images',		'fields' => [			'url' => 'Image Url',		],	],
		'colors' => [		'title' => 'Colors',		'fields' => [			'name' => 'Color name',		],	],
		'sizes' => [		'title' => 'Sizes',		'fields' => [			'name' => 'Size name',		],	],
		'products' => [		'title' => 'Products',		'fields' => [			'category' => 'Category',			'source-url' => 'Source url',			'name' => 'Product Name',			'sku' => 'Sku',			'old-price' => 'Old price',			'new-price' => 'New price',			'regular-price' => 'Regular price',			'description' => 'Description',			'first-accordion-content' => 'First accordion content',			'second-accordion-content' => 'Second accordion content',			'images' => 'Images',			'colors' => 'Colors',			'sizes' => 'Sizes',		],	],
];