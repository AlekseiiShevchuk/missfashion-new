<?php

return [
	'create' => 'बनाइए (क्रिएट)',
	'save' => 'सुरक्षित करे ',
	'edit' => 'संपादित करे (एडिट)',
	'view' => 'देखें',
	'update' => 'सुधारे ',
	'list' => 'सूची',
	'no_entries_in_table' => 'टेबल मे एक भी एंट्री नही है ',
	'custom_controller_index' => 'विशेष(कस्टम) कंट्रोलर इंडेक्स ।',
	'logout' => 'लोग आउट',
	'add_new' => 'नया समाविष्ट करे',
	'are_you_sure' => 'आप निस्चित है ?',
	'back_to_list' => 'सूची पे वापस जाए',
	'dashboard' => 'डॅशबोर्ड ',
	'delete' => 'मिटाइए',
	'quickadmin_title' => 'missfashion admin panel',
		'user-management' => [		'title' => 'User Management',		'fields' => [		],	],
		'roles' => [		'title' => 'Roles',		'fields' => [			'title' => 'Title',		],	],
		'users' => [		'title' => 'Users',		'fields' => [			'name' => 'Name',			'email' => 'Email',			'password' => 'Password',			'role' => 'Role',			'remember-token' => 'Remember token',		],	],
		'donor' => [		'title' => 'Donor category links',		'fields' => [			'url' => 'Url to donor category',			'category' => 'Parsing inside Category',		],	],
		'categories' => [		'title' => 'Categories',		'fields' => [			'name' => 'Category name',			'parent' => 'Parent category',			'photo' => 'Photo for category',			'donors' => 'Donors links',		],	],
		'product-attributes' => [		'title' => 'Product attributes',		'fields' => [		],	],
		'images' => [		'title' => 'Images',		'fields' => [			'url' => 'Image Url',		],	],
		'colors' => [		'title' => 'Colors',		'fields' => [			'name' => 'Color name',		],	],
		'sizes' => [		'title' => 'Sizes',		'fields' => [			'name' => 'Size name',		],	],
		'products' => [		'title' => 'Products',		'fields' => [			'category' => 'Category',			'source-url' => 'Source url',			'name' => 'Product Name',			'sku' => 'Sku',			'old-price' => 'Old price',			'new-price' => 'New price',			'regular-price' => 'Regular price',			'description' => 'Description',			'first-accordion-content' => 'First accordion content',			'second-accordion-content' => 'Second accordion content',			'images' => 'Images',			'colors' => 'Colors',			'sizes' => 'Sizes',		],	],
];