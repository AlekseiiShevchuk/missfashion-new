<?php

use Illuminate\Database\Seeder;

class CategorySeedPivot extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            
            5 => [
                'donors' => [1, 2],
            ],

        ];

        foreach ($items as $id => $item) {
            $category = \App\Category::find($id);

            foreach ($item as $key => $ids) {
                $category->{$key}()->sync($ids);
            }
        }
    }
}
