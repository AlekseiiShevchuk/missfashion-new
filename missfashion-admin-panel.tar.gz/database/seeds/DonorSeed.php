<?php

use Illuminate\Database\Seeder;

class DonorSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            
            ['id' => 1, 'url' => 'http://www.some-domen.com/hydra/', 'category_id' => null,],
            ['id' => 2, 'url' => 'http://www.some-domen.com/hydr', 'category_id' => null,],

        ];

        foreach ($items as $item) {
            \App\Donor::create($item);
        }
    }
}
